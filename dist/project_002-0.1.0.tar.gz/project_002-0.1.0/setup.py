# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['project_002']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'project-002',
    'version': '0.1.0',
    'description': 'A test project with two folders does nothing interesting',
    'long_description': None,
    'author': 'Helen Duncan',
    'author_email': 'hduncan@turing.ac.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
