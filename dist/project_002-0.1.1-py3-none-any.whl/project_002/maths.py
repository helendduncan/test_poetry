def add_one(x=None):
    x = x + 1 if x is not None else 1
    return x

def add_two(x=None):
    x = x + 2 if x is not None else 2
    return x

def times_three(x=None):
    x = x * 3 if x is not None else 0
    return x
